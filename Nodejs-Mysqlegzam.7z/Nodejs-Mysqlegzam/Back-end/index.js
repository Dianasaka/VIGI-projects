import { config } from 'dotenv'
import mysql from 'mysql2/promise'
import express from 'express'

config()
const app = express();

app.use(express.json());

const PORT = 5_001;

const MYSQL_CONFIG = "mysql://doadmin:AVNS_wEvOxN2zWRkCM6NlXd4@codeacademy-database-cluster-do-user-13090074-0.b.db.ondigitalocean.com:25060defaultdb";

app.post("/", async (req, res) => {
    const { users, groups, bills, accounts } = req.body;
});

app.listen(PORT, () => {
    console.log(`Listening on ${PORT}`);
});
