const express = require("express");
const Joi = require('joi')

const router = express.Router();

const userSchema = Joi.object({
    id: Joi.string().required(),
    email: Joi.string().email().trim().lowercase().required(),
    name: Joi.string().required(),
    password: Joi.string().required(),
})
